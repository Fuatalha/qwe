# ETicaret2022Guz
E-Ticaret MVC Projesini 2022 Güz Döneminde Medipol Öğrencileri ile birlikte yapılıyor
Entity Framew Work
MVC .Net 6.00 Core
Projede SOLID prensibleri kullanarak N-Tier mimarisi ve Repository design pattern kullanılıyor
Veritabanı olarak MS SQL Server kullanılıyor

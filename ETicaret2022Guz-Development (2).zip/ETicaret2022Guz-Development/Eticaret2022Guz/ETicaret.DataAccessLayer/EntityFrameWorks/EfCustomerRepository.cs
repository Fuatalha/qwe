﻿using ETicaret.DataAccessLayer.Abstracts;
using ETicaret.DataAccessLayer.Repositories;
using ETicaret.EntityLayer.Concretes;

namespace ETicaret.DataAccessLayer.EntityFrameWorks
{
    public class EfCustomerRepository : EfRepositoyBase<Customer>, ICustomerDal
    {

    }

}

﻿using ETicaret.EntityLayer.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.DataAccessLayer.Mappings
{
    public class ShoppingcardMap : IEntityTypeConfiguration<Shoppingcard>
    {

        public void Configure(EntityTypeBuilder<Shoppingcard> Builder)
        {

            Builder.ToTable("Shoppingcard")
                          .Property(a => a.CardName).HasColumnType("nvarchar").HasMaxLength(50).IsRequired();


            Builder.HasKey(" ShoppingCardId ");

            Builder.Property(x => x.CardNumber).HasColumnName("varchar").HasMaxLength(12);

            Builder.Property(X=> X.CardType).HasColumnName("CardType").HasDefaultValue(true).IsRequired();   // kredi kartı veya banka kartı 
                                                                                                             // true kredi kartı //false banka kartı


            Builder.Property(x => x.ShoppingcardStatu).HasColumnName("ShoppingcardStatu").HasDefaultValue(true).IsRequired();





        }


    }
}

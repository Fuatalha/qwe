﻿using ETicaret.EntityLayer.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace ETicaret.DataAccessLayer.Mappings
{
   public  class AdressMap : IEntityTypeConfiguration<Adress>
    {
        public void Configure(EntityTypeBuilder<Adress> builder)
        {

        

        builder.Property(x => x.AdressName)
            .HasColumnType("nvarchar")
            .HasMaxLength(100)
            .IsRequired();



         builder.HasKey(x => x.AdressId);


         builder.Property(x => x.AdressDescription)
           .HasColumnType("nvarchar")
            .HasMaxLength(250)
             .IsRequired();


         builder.Property(x => x.CityName)
                 .HasColumnType("nvarchar")
                 .HasMaxLength(50);


         builder.Property(x => x.TownName)
                     .HasColumnType("nvarchar")
                     .HasMaxLength(50);



            builder.Property(x => x.AdressDescription)
                 .HasColumnType("nvarchar")
                  .HasMaxLength(250);
          

            builder.Property(x => x.PhoneNumber)
                .HasColumnName("varchar")
                .HasMaxLength(15);
        }
    }
}


﻿using ETicaret.BussinessLayer.Abstract;
using ETicaret.EntityLayer.Concretes;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Eticaret.WepAPI.Controllers
{


    [Route("api/[controller]")]
    [ApiController]
    public class AdressController : ControllerBase
    {
        private readonly IAdressService _IAdressService;

        public AdressController(IAdressService IAdressService)
        {
            _IAdressService = IAdressService;
        }

        [HttpGet]
        [Route("[action]")]
        public async Task<IActionResult> GetList()
        {
            var result = await _IAdressService.GetListAsync(x => x.AdressStatus == true);
            if (result is not null)
                return Ok(result);
            return NotFound(result);
        }

        [HttpGet]
        [Route("[action]/{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var result = await _IAdressService.GetModelByIdAsync(id);
            if (result is not null)
                return Ok(result);
            return NotFound(result);
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Add([FromBody] Adress adress)
        {
            var result = await _IAdressService.AddAsync(adress);
            if (result is not null)
                return Ok(result);
            return BadRequest(result);
        }

        [HttpDelete]
        [Route("[action]/{id:int}")]

        public async Task<IActionResult> Delete(int id)
        {
            var result = await _IAdressService.DeleteByIdAsync(id);
            if (result)
                return Ok(result);
            return NotFound(result);
        }


 

     

        [HttpPut]
        [Route("[action]")]

        public async Task<IActionResult> Update([FromBody] Adress adress)
        {
            var result = await _IAdressService.UpdateAsync(adress);
            if (result is not null)
                return Ok(result);
            return BadRequest(result);
        }

    }
}




    


﻿using ETicaret.BussinessLayer.Abstract;
using ETicaret.EntityLayer.Concretes;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Eticaret.WepAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingcardController : ControllerBase
    {
        private readonly IShoppingcardService _IShoppingcardService;

        public ShoppingcardController(IShoppingcardService IShoppingcardService)
        {
            _IShoppingcardService = IShoppingcardService;
        }

        [HttpGet]
        [Route("[action]")]
        public async Task<IActionResult> GetList()
        {
            var result = await _IShoppingcardService.GetListAsync(x => x.ShoppingcardStatu == true);
            if (result is not null)
                return Ok(result);
            return NotFound(result);
        }

        [HttpGet]
        [Route("[action]/{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var result = await _IShoppingcardService.GetModelByIdAsync(id);
            if (result is not null)
                return Ok(result);
            return NotFound(result);
        }

        [HttpPost]
        [Route("[action]")]
        public async Task<IActionResult> Add([FromBody] Shoppingcard shoppingcard)
        {
            var result = await _IShoppingcardService.AddAsync(shoppingcard);
            if (result is not null)
                return Ok(result);
            return BadRequest(result);
        }

        [HttpDelete]
        [Route("[action]/{id:int}")]

        public async Task<IActionResult> Delete(int id)
        {
            var result = await _IShoppingcardService.DeleteByIdAsync(id);
            if (result)
                return Ok(result);
            return NotFound(result);
        }






        [HttpPut]
        [Route("[action]")]

        public async Task<IActionResult> Update([FromBody] Shoppingcard shoppingcard)
        {
            var result = await _IShoppingcardService.UpdateAsync(shoppingcard);
            if (result is not null)
                return Ok(result);
            return BadRequest(result);
        }

    }
}





    
﻿using ETicaret.EntityLayer.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.BussinessLayer.Abstract
{
    public interface IAdressService
    {

        Task<Adress> AddAsync(Adress adress);
        Task<Adress> UpdateAsync(Adress adress);
        Task<bool> DeleteByIdAsync(int id);

        Task<List<Adress>> GetListAsync(Expression<Func<Adress, bool>> filter = null);

        Task<Adress> GetAsync(Expression<Func<Adress, bool>> filter);

        Task<Adress> GetModelByIdAsync(int id);
        
    }
}

﻿using ETicaret.EntityLayer.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.BussinessLayer.Abstract
{
    public interface IShoppingcardService
    {
        Task<Shoppingcard> AddAsync(Shoppingcard shoppingcard);
        Task<Shoppingcard> UpdateAsync(Shoppingcard shoppingcard);
        Task<bool> DeleteByIdAsync(int id);

        Task<List<Shoppingcard>> GetListAsync(Expression<Func<Shoppingcard, bool>> filter = null);

        Task<Shoppingcard> GetAsync(Expression<Func<Shoppingcard, bool>> filter);

        Task<Shoppingcard> GetModelByIdAsync(int id);


    }
}

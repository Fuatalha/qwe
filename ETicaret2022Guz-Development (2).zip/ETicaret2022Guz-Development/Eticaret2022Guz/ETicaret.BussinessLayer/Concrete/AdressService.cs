﻿using ETicaret.BussinessLayer.Abstract;
using ETicaret.DataAccessLayer.Abstracts;
using ETicaret.EntityLayer.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.BussinessLayer.Concrete
{
        public class AdressService : IAdressService
        {
            private readonly IAdressService _adressDal;

            public AdressService(IAdressDal adressDal)
            {
                _adressDal = (IAdressService)adressDal;
            }

            public async Task<Adress> AddAsync(Adress adress)
            {
                var addAdress = await _adressDal.AddAsync(adress);

                return addAdress;
            }

            public async Task<bool> DeleteByIdAsync(int id)
            {
                return await _adressDal.DeleteByIdAsync(id);
            }

        public Task Get3AdressAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<Adress> GetAsync(Expression<Func<Adress, bool>> filter)
            {
                return await _adressDal.GetAsync(filter);

            }

            public async Task<List<Adress>> GetListAsync(Expression<Func<Adress, bool>> filter = null)
            {

                return await _adressDal.GetListAsync(filter);

            }

            public async Task<Adress> GetModelByIdAsync(int id)
            {
                return await _adressDal.GetModelByIdAsync(id);
            }

            public async Task<Adress> UpdateAsync(Adress adress)
            {
                return await _adressDal.UpdateAsync(adress);
            }
        }


    }


﻿using ETicaret.BussinessLayer.Abstract;
using ETicaret.DataAccessLayer.Abstracts;
using ETicaret.EntityLayer.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.BussinessLayer.Concrete
{
   public  class ShoppingcardService : IShoppingcardService
    {

        private readonly IShoppingcardService _shoppingcardDal;

        public ShoppingcardService(IShoppingcardDal shoppingcardDal)
        {
            _shoppingcardDal = (IShoppingcardService)shoppingcardDal;
        }

        public async Task<Shoppingcard> AddAsync(Shoppingcard shoppingcard)
        {
            var addShoppingcard = await _shoppingcardDal.AddAsync(shoppingcard);

            return addShoppingcard;
        }

        public async Task<bool> DeleteByIdAsync(int id)
        {
            return await _shoppingcardDal.DeleteByIdAsync(id);
        }

        public Task Get3ShoppingcardAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<Shoppingcard> GetAsync(Expression<Func<Shoppingcard, bool>> filter)
        {
            return await _shoppingcardDal.GetAsync(filter);

        }

        public async Task<List<Shoppingcard>> GetListAsync(Expression<Func<Shoppingcard, bool>> filter = null)
        {

            return await _shoppingcardDal.GetListAsync(filter);

        }

        public async Task<Shoppingcard> GetModelByIdAsync(int id)
        {
            return await _shoppingcardDal.GetModelByIdAsync(id);
        }

        public async Task<Shoppingcard> UpdateAsync(Shoppingcard shoppingcard)
        {
            return await _shoppingcardDal.UpdateAsync(shoppingcard);
        }
    }


}


﻿using ETicaret.EntityLayer.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETicaret.EntityLayer.Concretes
{
    public class Shoppingcard:IEntity
    {
        public int ShoppingCardId { get; set; }

        public string CardName { get; set; }

        public int CardNumber { get; set; }

        public string CardType { get; set; }

        public bool ShoppingcardStatu { get; set; }
        
    }
}
